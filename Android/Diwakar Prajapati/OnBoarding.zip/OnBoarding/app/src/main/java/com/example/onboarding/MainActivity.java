package com.example.onboarding;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.text.Html;
import android.transition.Slide;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private ViewPager viewpager;
    private LinearLayout dotslayout;
    private SliderAdaptar sliderAdaptar;
    private TextView[] dots;
    private Button backBtn, nextBtn, skipBtn;
    int currentpage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        viewpager = (ViewPager)findViewById(R.id.viewPager);
        dotslayout = (LinearLayout)findViewById(R.id.dotslayout);
        backBtn = (Button)findViewById((R.id.backBtn));
        nextBtn = (Button)findViewById((R.id.nextBtn));
        skipBtn = (Button)findViewById((R.id.skipBtn));

        sliderAdaptar = new SliderAdaptar(this);
        viewpager.setAdapter(sliderAdaptar);

        addDotIndicator(0);

        viewpager.addOnPageChangeListener(listener);

        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewpager.setCurrentItem(currentpage+1);
            }
        });
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewpager.setCurrentItem(currentpage-1);
            }
        });
        skipBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewpager.setCurrentItem(2);
            }
        });
    }

    public void addDotIndicator(int position){
        dots = new TextView[3];
        dotslayout.removeAllViews();
        for(int i=0; i<dots.length; i++){
            dots[i] = new TextView(this);
            dots[i].setText(Html.fromHtml("&#8226;&nbsp;"));
            dots[i].setTextSize(35);
            dots[i].setTextColor(getResources().getColor(R.color.teal_700));
            dotslayout.addView(dots[i]);
        }

        if(dots.length>0){
            dots[position].setTextColor(getResources().getColor(R.color.white));
        }
    }

    ViewPager.OnPageChangeListener listener = new ViewPager.OnPageChangeListener() {
        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        @Override
        public void onPageSelected(int position) {
            addDotIndicator(position);
            currentpage = position;
            if(currentpage==0){
                backBtn.setEnabled(false);
                nextBtn.setEnabled(true);
                backBtn.setVisibility(View.INVISIBLE);
                skipBtn.setVisibility(View.VISIBLE);
                nextBtn.setText("NEXT");
                backBtn.setText("BACK");
            }
            else if(currentpage==dots.length-1){
                backBtn.setEnabled(true);
                nextBtn.setEnabled(true);
                backBtn.setVisibility(View.VISIBLE);
                skipBtn.setVisibility(View.INVISIBLE);
                nextBtn.setText("DONE");
                backBtn.setText("BACK");
            }
            else{
                backBtn.setEnabled(true);
                nextBtn.setEnabled(true);
                backBtn.setVisibility(View.VISIBLE);
                skipBtn.setVisibility(View.VISIBLE);
                nextBtn.setText("NEXT");
                backBtn.setText("BACK");
            }

        }

        @Override
        public void onPageScrollStateChanged(int state) {

        }
    };

}